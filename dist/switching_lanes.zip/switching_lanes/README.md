About
This project is a 2D python game that utilizes the PYGAME module and sqlite3 for the database implementation and contains and .exe file to be run as an application.

Description
In the game the player plays a motorcycle that rides on a road. 
On the road obstacles appear.
The player has the options to shoots the obstacles.
Throughout the game the player will earn points for obstacles cleared and double for destroying them and will progress through waves.
The game will increase in difficulty as the waves progress.
At the end the game will prompt you for your name and then add you to the database and display a leaderboard.
You can replay as much as you like and hopefully improve.

Controls
To move right and left use the a and d keys respectaply.
To shoot projectiles use the space bar.
To advance In the menues use the Enter/Return key.
To type your name use your keyboard but try to keep it simple and in english.

HAVE FUN!!!